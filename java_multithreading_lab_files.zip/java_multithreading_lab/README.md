# Java Multithreading Lab

## Aim
Create three concurrent threads that print `Good Morning`, `Hello`, and `Welcome` every 1, 2, and 3 seconds.

## Files
- `ThreadClassMethod.java` — creates threads by extending the `Thread` class.
- `RunnableInterfaceMethod.java` — creates threads by implementing the `Runnable` interface.
- `sample_output.txt` — example of the kind of interleaved output you may see.

## Compile and run

### Method 1: Extending Thread
```bash
javac ThreadClassMethod.java
java ThreadClassMethod
```

### Method 2: Implementing Runnable
```bash
javac RunnableInterfaceMethod.java
java RunnableInterfaceMethod
```

Both programs intentionally run continuously. Stop them with **Ctrl+C** in the terminal. The order of messages can vary because the threads execute concurrently.
